﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;
using System.Linq;
using System.Text.RegularExpressions;
using MathLibrary;


namespace CalculatorForms
{
    public partial class Calculator : Form
    {
        private Dictionary<string, CalculatorOperations> _symbolDictionary;
        private string _expression;

        public Calculator()
        {
            InitializeComponent();
        }

        private void Calculator_Load(object sender, EventArgs e)
        {
            
            CalculatorLowerBody calc = new CalculatorLowerBody();
            _symbolDictionary = calc.GetDictionary();
            numberSet.ColumnCount = 4;
            numberSet.RowCount = _symbolDictionary.Count / numberSet.ColumnCount;
            numberSet.Location = new Point(10, 183);
            numberSet.Name = "numberSet";
            numberSet.Size = new Size(370, 390);

            int counter = 0;
            for (int i = 0; i < numberSet.RowCount; i++)
            {
                for (int j = 0; j < numberSet.ColumnCount; j++)
                {
                    Button button = new Button();
                    numberSet.Controls.Add(button, j, i);
                    button.Dock = DockStyle.Fill;
                    button.Location = new Point(1, 1);
                    button.Margin = new Padding(1);
                    button.Name = "button " + counter.ToString();
                    button.Size = new Size(95, 58);
                    button.Text = _symbolDictionary.Values.ElementAt(counter).Display;
                    button.Click += new EventHandler(btn_click);
                    counter += 1;
                }
            }
            result.Dock = DockStyle.Fill;
            result.Font = new Font("Arial", 24, FontStyle.Bold);
            result.Margin = new Padding(10);
        }

        private void btn_click(object sender, EventArgs e)
        {
            Button btn = (Button)sender;
            string buttonName = btn.Name;

            //Removes alphabets from button name, leaving only the number i.e. its index at operation dictionary
            int buttonIndex = int.Parse(Regex.Replace(buttonName, "[A-Za-z ]", ""));

            // Displays the symbol in the textbox
            string displaySymbol = _symbolDictionary.Values.ElementAt(buttonIndex).Display;

            // Actual symbol in English
            string expressionSymbol = _symbolDictionary.Values.ElementAt(buttonIndex).Symbol;

            if (displaySymbol == _symbolDictionary["ClearAll"].Display)
            {
                result.Text = String.Empty;
                _expression = string.Empty;
            }

            //Clears entry
            else if (displaySymbol == _symbolDictionary["ClearEntry"].Display)
            {
                result.Text = String.Empty;
            }

            // Erase
            else if (displaySymbol == _symbolDictionary["Erase"].Display)
            {
                if (result.Text.Length > 0)
                {
                    result.Text = result.Text.Substring(0, result.TextLength - displaySymbol.Length + 1);
                    _expression = _expression.Substring(0, _expression.Length - displaySymbol.Length + 1);
                }
            }

            // Decimal
            else if (!result.Text.Contains(_symbolDictionary["Decimal"].Display) && displaySymbol == _symbolDictionary["Decimal"].Display)
            {
                result.Text += displaySymbol;
                _expression += expressionSymbol;
            }

            //Evaluate
            else if (displaySymbol == _symbolDictionary["Equal"].Display)
            {
                ExpresssionEvaluator evaluator = new ExpresssionEvaluator();
                result.Text = evaluator.Evaluate(_expression).ToString();
            }

            //Operand or operator
            else
            {
                if (displaySymbol != _symbolDictionary["Decimal"].Display)
                {
                    result.Text += expressionSymbol;
                    _expression += expressionSymbol;
                }
            }
        }
    }
}