﻿using System;
using System.Collections.Generic;
using Newtonsoft.Json;

namespace CalculatorForms
{
    public class CalculatorLowerBody
    {
        private Dictionary<string, CalculatorOperations> _calculatorOperations;
        public CalculatorLowerBody()
        {
            string calculatorOperations;

            try
            {
                calculatorOperations = System.IO.File.ReadAllText("BasicCalculatorOperation.json");
            }
            catch (Exception e)
            {
                throw e;
            }
            var calculatorOperationsdata = JsonConvert.DeserializeObject<Dictionary<string, CalculatorOperations>>(calculatorOperations);
            _calculatorOperations = new Dictionary<string, CalculatorOperations> { };
            foreach (var operation in calculatorOperationsdata)
            {
                _calculatorOperations.Add(operation.Key, operation.Value);
            }
        }
        public Dictionary<string, CalculatorOperations> GetDictionary()
        {
            return _calculatorOperations;
        }
    }
}

