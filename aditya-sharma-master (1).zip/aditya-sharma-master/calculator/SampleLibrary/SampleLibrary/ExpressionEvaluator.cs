﻿using System;
using System.Collections.Generic;
using Newtonsoft.Json;
using SampleLibrary;
namespace MathLibrary
{
    public class ExpresssionEvaluator
    {

        private Dictionary<string, OperationData> _operationsDictionary;

        private InfixToPostfixConverter _converter;

        public ExpresssionEvaluator()
        {
            string operationsDataJson;

            try
            {
                operationsDataJson = System.IO.File.ReadAllText("OperatorsData.json");
            }
            catch (Exception e)
            {
                throw new MathLibraryExceptions.OperatorFileNotFoundException(e);
            }
            var operationsData = JsonConvert.DeserializeObject<Dictionary<string, OperationData>>(operationsDataJson);
            try
            {
                operationsData["Sum"].Operation = new SumOperation();
                operationsData["Subtract"].Operation = new SubtractOperation();
                operationsData["Product"].Operation = new ProductOperation();
                operationsData["Divide"].Operation = new DivideOperation();
                operationsData["Power"].Operation = new PowerOperation();
                operationsData["SquareRoot"].Operation = new SquareRootOperation();
                operationsData["Negate"].Operation = new NegateOperation();
                operationsData["Percentage"].Operation = new PercentageOperation();
                operationsData["Log"].Operation = new LogOperation();
                operationsData["Ln"].Operation = new LnOperation();
                operationsData["Sin"].Operation = new SinOperation();
                operationsData["Cos"].Operation = new CosOperation();
                operationsData["Tan"].Operation = new TanOperation();
                operationsData["Cosec"].Operation = new CosecOperation();
                operationsData["Sec"].Operation = new SecOperation();
                operationsData["Cot"].Operation = new CotOperation();
            }
            catch (Exception e)
            {
                throw new MathLibraryExceptions.OperatorDoesNotExistsException(e);
            }

            // Dictionary containing information of operators
            _operationsDictionary = new Dictionary<string, OperationData> { };

            foreach (var operation in operationsData)
            {
                _operationsDictionary.Add(operation.Key, operation.Value);
            }

            // Instance to call postfix converter
            _converter = new InfixToPostfixConverter();
        }

        // Registers Custom Operations
        public void RegisterCustomOperation(string operation, string symbol, int precedence)
        {
            if (operation is null)
                throw new MathLibraryExceptions.InvalidOperationClassException(operation);
            if (symbol is null)
                throw new MathLibraryExceptions.InvalidSymbolExcpetion(symbol);
            if (precedence < 0)
                throw new MathLibraryExceptions.InvalidPrecedenceException();

            // If symbol already exists
            if (_operationsDictionary.ContainsKey(symbol))
            {
                throw new MathLibraryExceptions.SymbolAlreadyExistsException(symbol);
            }

            // Add operation to dictionary
            else
            {
                OperationData operationData = new OperationData();
                operationData.Symbol = symbol;
                operationData.Precedence = precedence;
                _operationsDictionary.Add(operation, operationData);
            }
        }

        // Evaluates mathematical expression
        public double Evaluate(string expression)
        {
            // Convert infix string to postfix string

            string postfixExpression = _converter.InfixToPostfix(expression, _operationsDictionary);
            //string postfixExpression = InfixToPostfixConverter.InfixToPostfix(expression);

            postfixExpression = postfixExpression.Trim();

            // Tokenize postfix expression by removing spaces
            string[] expresionToken = postfixExpression.Split(new char[] { ' ', '\t' }, StringSplitOptions.RemoveEmptyEntries);

            // Evaluation stack
            Stack<double> eval = new Stack<double>();

            for (int x = 0; x < expresionToken.Length; x++)
            {
                int flag = 0;
                // If operator exists in dictionary
                foreach (var operation in _operationsDictionary)
                {
                    if (operation.Value.Symbol == expresionToken[x])
                    {
                        int operandCount = operation.Value.Operation.OperandCount;
                        flag = 1;
                        // Store operands as per their operator's count
                        double[] operands = new double[operandCount];
                        for (int i = 0; i < operandCount; i++)
                        {
                            try
                            {
                                operands[i] = eval.Pop();
                            }
                            catch (Exception ex)
                            {
                                throw new MathLibraryExceptions.InvalidOperationException(ex);
                            }
                        }

                        //Call evaluate function of respective operator
                        eval.Push(operation.Value.Operation.Evaluate(operands));
                    }
                }
                // Push result back to eval stack as double
                if(flag==0)
                {
                    try
                    {
                        eval.Push(Convert.ToDouble(expresionToken[x]));
                    }
                    catch (Exception)
                    {
                        throw new MathLibraryExceptions.InvalidOpreatorFoundException(expresionToken[x]);
                    }
                }
            }
            //Return final result of calcualation
            return eval.Pop();
        }
    }
}