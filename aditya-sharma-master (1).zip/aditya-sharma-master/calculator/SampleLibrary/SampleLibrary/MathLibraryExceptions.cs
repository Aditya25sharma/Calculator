﻿using System;

namespace SampleLibrary
{
    public class MathLibraryExceptions : Exception
    {
        public MathLibraryExceptions()
        {

        }
        public class OperatorDoesNotExistsException : Exception
        {
            public OperatorDoesNotExistsException()
            {
                throw new Exception(ExceptionResource.OperatorDoesNotExistsException);
            }
            public OperatorDoesNotExistsException(Exception message)
            {
                throw new Exception(ExceptionResource.OperatorDoesNotExistsException, message);
            }
        }
        public class OperatorFileNotFoundException : Exception
        {
            public OperatorFileNotFoundException()
            {
                throw new Exception(ExceptionResource.OperatorFileNotFoundException);
            }
            public OperatorFileNotFoundException(Exception message)
            {
                throw new Exception(ExceptionResource.OperatorFileNotFoundException, message);
            }
        }

        public class InvalidOpreatorFoundException : Exception
        {
            public InvalidOpreatorFoundException()
            {
                throw new Exception(ExceptionResource.InvalidOperatorFoundException);
            }
            public InvalidOpreatorFoundException(string message)
            {
                throw new Exception(message + ExceptionResource.InvalidOperatorFoundException);
            }
            public InvalidOpreatorFoundException(Exception e, string message)
            {
                throw new Exception(message + ExceptionResource.InvalidOperatorFoundException ,e);
            }
        }

        public class InvalidOperationException: Exception
        {
            public InvalidOperationException()
            {
                throw new Exception(ExceptionResource.InvalidOperationException);
            }
            public InvalidOperationException(Exception e)
            {
                throw new Exception(ExceptionResource.InvalidOperationException, e);
            }
        }

        public class OperandsMissingException: Exception
        {
            public OperandsMissingException()
            {
                throw new Exception(ExceptionResource.OperandMissingException);
            }
            public OperandsMissingException(Exception e)
            {
                throw new Exception (ExceptionResource.OperandMissingException, e);
            }
            public OperandsMissingException(int numberOfOperands)
            {
                throw new Exception(numberOfOperands+ExceptionResource.OperandMissingException);
            }
        }
        public class InvalidSymbolExcpetion: Exception
        {
            public InvalidSymbolExcpetion()
            {
                throw new Exception(ExceptionResource.InvalidSymbolException);
            }
            public InvalidSymbolExcpetion(string symbol)
            {
                throw new Exception(symbol+ExceptionResource.InvalidSymbolException);
            }
            public InvalidSymbolExcpetion(string symbol, Exception e)
            {
                throw new Exception(symbol+ExceptionResource.InvalidSymbolException, e);
            }
        }
        public class InvalidOperationClassException: Exception
        {
            public InvalidOperationClassException()
            {
                throw new Exception(ExceptionResource.InvalidOperationClassException);
            }
            public InvalidOperationClassException(string operationClass)
            {
                throw new Exception(operationClass+ExceptionResource.InvalidOperationClassException);
            }
            public InvalidOperationClassException(Exception e)
            {
                throw new Exception(ExceptionResource.InvalidOperationClassException, e);
            }
        }
        public class InvalidPrecedenceException: Exception
        {
            public InvalidPrecedenceException()
            {
                throw new Exception(ExceptionResource.InvalidPrecedenceException);
            }
            public InvalidPrecedenceException(Exception e)
            {
                throw new Exception (ExceptionResource.InvalidPrecedenceException, e);
            }
        }
        public class SymbolAlreadyExistsException: Exception
        {
            public SymbolAlreadyExistsException()
            {
                throw new Exception(ExceptionResource.SymbolAlreadyExistsException);
            }
            public SymbolAlreadyExistsException(string symbol)
            {
                throw new Exception(symbol+ExceptionResource.SymbolAlreadyExistsException);
            }
            public SymbolAlreadyExistsException(string symbol, Exception e)
            {
                throw new Exception(symbol + ExceptionResource.SymbolAlreadyExistsException, e);
            }
        }
    }
}
