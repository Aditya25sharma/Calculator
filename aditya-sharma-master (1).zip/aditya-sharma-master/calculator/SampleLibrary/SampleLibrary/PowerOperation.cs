﻿using System;

namespace MathLibrary
{
    internal class PowerOperation : BinaryOperation
    {
        protected override double EvaluateInternal(double[] values)
        {
            try
            {
                double power = Math.Pow(values[1], values[0]); ;
                return power;
            }
            catch (OverflowException e)
            {
                throw e;
            }
        }
    }
}