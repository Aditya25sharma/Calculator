﻿using SampleLibrary;
using System.Collections.Generic;

namespace MathLibrary
{
    internal class InfixToPostfixConverter
    {
        //returns precedence of operator
        internal int GetPrecedence(string searchSymbol, Dictionary<string, OperationData> operationDictionary)
        {
            foreach (var operation in operationDictionary)
            {
                if(operation.Value.Symbol == searchSymbol)
                {
                    return operation.Value.Precedence;
                }
            }
            return -1;
        }

        internal string InfixToPostfix(string expression, Dictionary<string, OperationData> operationDictionary)
        {

            // initializing empty String for result
            string result = string.Empty;

            // initializing empty stack
            Stack<string> stack = new Stack<string>();

            for (int i = 0; i < expression.Length; ++i)
            {
                char expressionElement = expression[i];

                // If the scanned character is an operand or decimal, add it to output.
                if (char.IsDigit(expressionElement) || expressionElement == '.')
                {
                    result += expressionElement;
                }

                // If the scanned character is an '(', push it to the stack.
                else if (expressionElement == '(')
                {
                    stack.Push(expressionElement + string.Empty);
                }

                // If the scanned character is an ')',pop and output until an '(' is encountered.
                else if (expressionElement == ')')
                {
                    while (stack.Count > 0 && stack.Peek() != "(")
                    {
                        result += " ";
                        result += stack.Pop();
                    }
                    if (stack.Count > 0 && stack.Peek() != "(")
                    {
                        // Invalid expression
                        throw new MathLibraryExceptions.InvalidOperationException();
                    }
                    else
                    {
                        // Invalid expression
                        if (stack.Count == 0)
                        {
                            throw new MathLibraryExceptions.InvalidOperationException();
                        }
                        //Pop () expression
                        stack.Pop();
                    }
                }

                // If a multicharacter operator is encountered
                else if (char.IsLetter(expressionElement))
                {

                    string operatorName = string.Empty;
                    for (; char.IsLetter(expression[i]); i++)
                    {
                        operatorName += expression[i];
                    }
                    i--;
                    while (stack.Count > 0 && GetPrecedence(operatorName, operationDictionary) <= GetPrecedence(stack.Peek() + string.Empty, operationDictionary))
                    {
                        if(stack.Count == 0)
                        {
                            throw new MathLibraryExceptions.InvalidOperationException();
                        }
                        else
                        {
                            result += " " + stack.Pop();
                        }
                    }
                    result += " ";
                    stack.Push(operatorName);
                }

                // Single character operator is encountered
                else
                {
                    while (stack.Count > 0 && GetPrecedence(expressionElement + string.Empty, operationDictionary) <= GetPrecedence(stack.Peek() + string.Empty, operationDictionary))
                    {
                        result += " ";
                        result += stack.Pop();
                    }
                    result += " ";
                    stack.Push(expressionElement + string.Empty);
                }
            }

            // pop all the operators from the stack
            while (stack.Count > 0)
            {
                result += " " + stack.Pop();
            }
            return result;
        }
    }
}

