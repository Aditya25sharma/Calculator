﻿using SampleLibrary;

namespace MathLibrary
{
    abstract internal class UnaryOperation : IOperation
    {
        public int OperandCount { get; }
        public UnaryOperation()
        {
            OperandCount = 1;
        }
        public double Evaluate(double[] values)
        {
            if (values.Length != OperandCount)
                throw new MathLibraryExceptions.OperandsMissingException(OperandCount);

            return EvaluateInternal(values);
        }

        protected abstract double EvaluateInternal(double[] values);
    }
}
