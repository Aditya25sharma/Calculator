﻿using System;
using SampleLibrary;

namespace MathLibrary
{
    internal class DivideOperation : BinaryOperation
    {
        protected override double EvaluateInternal(double[] values)
        {
            try
            {
                double division = values[1] / values[0];
                if (double.IsInfinity(division))
                {
                    throw new Exception(ExceptionResource.DivideByZeroException);
                }
                return division;

            }
            catch (OverflowException e)
            {
                throw e;
            }
        }
    }
}
