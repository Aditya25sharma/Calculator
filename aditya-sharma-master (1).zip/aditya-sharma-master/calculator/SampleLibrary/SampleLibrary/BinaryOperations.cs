﻿using SampleLibrary;
namespace MathLibrary
{
    abstract internal class BinaryOperation : IOperation
    {
        public int OperandCount { get; }
        public BinaryOperation()
        {
            OperandCount = 2;
        }
        public double Evaluate(double[] values)
        {
            if (values.Length != OperandCount)
                throw new MathLibraryExceptions.OperandsMissingException(OperandCount);

            return EvaluateInternal(values);
        }

        // Calculaion of respective operation
        protected abstract double EvaluateInternal(double[] values);
    }
}
