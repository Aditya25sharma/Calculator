﻿using System;
using SampleLibrary;

namespace MathLibrary
{
    internal class TanOperation : UnaryOperation
    {
        protected override double EvaluateInternal(double[] values)
        {
            try
            {
                if (Math.Cos(values[0]) == 0)
                {
                    throw new Exception(ExceptionResource.DivideByZeroException);
                }
                double tan = Math.Tan((values[0] * (Math.PI)) / 180);
                return tan;
            }
            catch (Exception e)
            {
                throw e;
            }
        }
    }
}