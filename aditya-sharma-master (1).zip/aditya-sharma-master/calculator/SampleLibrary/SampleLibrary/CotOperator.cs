﻿using System;
using SampleLibrary;
namespace MathLibrary
{
    internal class CotOperation : UnaryOperation
    {
        protected override double EvaluateInternal(double[] values)
        {
            try
            {
                if (Math.Sin(values[0]) == 0)
                {
                    throw new Exception(ExceptionResource.DivideByZeroException);
                }
                double cot = 1 / Math.Tan(values[0] * Math.PI / 180);
                return cot;
            }
            catch (Exception e)
            {
                throw e;
            }
        }
    }
}
