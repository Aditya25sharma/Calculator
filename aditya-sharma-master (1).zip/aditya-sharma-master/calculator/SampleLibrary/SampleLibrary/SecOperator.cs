﻿using System;
using SampleLibrary;

namespace MathLibrary
{
    internal class SecOperation : UnaryOperation
    {
        protected override double EvaluateInternal(double[] values)
        {
            try
            {
                if (Math.Cos(values[0]) == 0)
                {
                    throw new Exception(ExceptionResource.DivideByZeroException);
                }
                double sec = 1 / Math.Cos(values[0] * Math.PI / 180);
                return sec;
            }
            catch (Exception e)
            {
                throw e;
            }
        }
    }
}
