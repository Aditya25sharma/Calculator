﻿using System;

namespace MathLibrary
{
    internal class LnOperation : UnaryOperation
    {
        protected override double EvaluateInternal(double[] values)
        {
            if (values[0] < 0)
            {
                throw new ArgumentOutOfRangeException();
            }
            double log = Math.Log(values[0]);
            return log;
        }
    }
}