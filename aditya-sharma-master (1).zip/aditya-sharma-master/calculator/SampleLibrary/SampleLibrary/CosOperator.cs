﻿using System;

namespace MathLibrary
{
    internal class CosOperation : UnaryOperation
    {
        protected override double EvaluateInternal(double[] values)
        {
            return Math.Cos(values[0] * Math.PI / 180);
        }
    }
}
