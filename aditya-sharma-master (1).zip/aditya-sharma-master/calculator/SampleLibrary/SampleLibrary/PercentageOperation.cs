﻿using System;

namespace MathLibrary
{
    internal class PercentageOperation : UnaryOperation
    {
        protected override double EvaluateInternal(double[] values)
        {
            try
            {
                double percentage = values[0] / 100;
                return percentage;
            }
            catch (OverflowException e)
            {
                throw e;
            }
        }
    }
}
