﻿using System;

namespace MathLibrary
{
    internal class NegateOperation : UnaryOperation
    {
        protected override double EvaluateInternal(double[] values)
        {
            try
            {
                double negate = -values[0];
                return negate;
            }
            catch (OverflowException e)
            {
                throw e;
            }
        }
    }
}
