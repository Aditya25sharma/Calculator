﻿using System;

namespace MathLibrary
{
    internal class SubtractOperation : BinaryOperation
    {
        protected override double EvaluateInternal(double[] values)
        {
            try
            {
                double difference = values[1] - values[0];
                return difference;
            }
            catch (Exception e)
            {
                throw e;
            }
        }
    }
}
