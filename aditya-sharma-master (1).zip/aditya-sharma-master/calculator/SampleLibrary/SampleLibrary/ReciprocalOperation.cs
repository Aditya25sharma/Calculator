﻿using System;
using SampleLibrary;

namespace MathLibrary
{
    internal class ReciprocalOperation : UnaryOperation
    {
        protected override double EvaluateInternal(double[] values)
        {
            try
            {
                double reciprocal = 1 / values[0];
                if (double.IsInfinity(reciprocal))
                {
                    throw new Exception(ExceptionResource.DivideByZeroException);
                }
                return reciprocal;
            }
            catch (OverflowException e)
            {
                throw e;
            }
        }
    }
}
