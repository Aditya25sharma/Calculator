﻿using System;

namespace MathLibrary
{
    internal class ProductOperation : BinaryOperation
    {
        protected override double EvaluateInternal(double[] values)
        {
            try
            {
                double product = values[0] * values[1];
                return product;
            }
            catch (OverflowException e)
            {
                throw e;
            }
        }
    }
}
