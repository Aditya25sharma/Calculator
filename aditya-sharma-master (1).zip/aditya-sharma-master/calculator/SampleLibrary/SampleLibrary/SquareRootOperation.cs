﻿using System;

namespace MathLibrary
{
    internal class SquareRootOperation : UnaryOperation
    {
        protected override double EvaluateInternal(double[] values)
        {
            if (values[0] < 0)
            {
                throw new ArgumentOutOfRangeException();
            }
            try
            {
                double root = Math.Pow(values[0], 0.5);
                return root;
            }
            catch (OverflowException e)
            {
                throw e;
            }
            catch (DivideByZeroException e)
            {
                throw e;
            }
        }
    }
}
