﻿
namespace MathLibrary
{
    public class OperationData
    {
        public string Symbol { get; set; }
        public int Precedence { get; set; }
        public IOperation Operation { get; set; }
    }

}