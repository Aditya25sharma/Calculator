﻿using System;

namespace MathLibrary
{
    internal class CosecOperation : UnaryOperation
    {
        protected override double EvaluateInternal(double[] values)
        {
            try
            {
                if (Math.Sin(values[0]) == 0)
                {
                    throw new DivideByZeroException();
                }
                double cosec = 1 / Math.Sin(values[0] * Math.PI / 180);
                return cosec;
            }
            catch (Exception e)
            {
                throw e;
            }
        }
    }
}
