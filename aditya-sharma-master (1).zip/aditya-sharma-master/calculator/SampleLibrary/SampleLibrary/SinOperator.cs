﻿using System;

namespace MathLibrary
{
    internal class SinOperation : UnaryOperation
    {
        protected override double EvaluateInternal(double[] values)
        {
            double sin = Math.Sin((values[0] * (Math.PI)) / 180);
            return sin;
        }
    }
}
