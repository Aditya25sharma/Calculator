﻿using CalculatorForms;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace MathLibrary.Tests
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestMethod1()
        {
            ExpresssionEvaluator ev = new ExpresssionEvaluator();
            double answer = ev.Evaluate("2+7");
            Calculator c = new Calculator();
            int a = 0;
           
        }
    }
}