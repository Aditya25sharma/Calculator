﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;

namespace WindowsFormsApp1
{
    public class OperationSymbols
    {
        private Dictionary<string, CalculatorOperations> _calculatorOperations;
        public OperationSymbols(string fileName)
        {
            string calculatorOperations;
            
            try
            {
                calculatorOperations = System.IO.File.ReadAllText(fileName+".json");
            }
            catch (Exception e)
            {
                throw e;
            }
            var calculatorOperationsdata = JsonConvert.DeserializeObject<Dictionary<string, CalculatorOperations>>(calculatorOperations);
            _calculatorOperations = new Dictionary<string, CalculatorOperations> { };
            foreach (var operation in calculatorOperationsdata)
            {
                _calculatorOperations.Add(operation.Key, operation.Value);
            }
        }
        public Dictionary<string, CalculatorOperations> GetDictionary()
        {
            return _calculatorOperations;
        }
    }
}

