﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using System.Text.RegularExpressions;
using MathLibrary;
using System.IO;

namespace WindowsFormsApp1
{
    public partial class CalculatorUI : Form
    {
        // Contains opertors and their symbol
        private Dictionary<string, CalculatorOperations> _symbolDictionary;

        // Equation expression
        private string _expression;

        // Operator and Operand set
        protected TableLayoutPanel _numberSet;

        // Result text box
        private TextBox _result;

        //Displays equation
        private TextBox _equation;

        //Menu
        private Menu _mainMenu;

        public static string option="Standard";
        public CalculatorUI()
        {
            InitializeComponent();
            OperationSymbols calc = new OperationSymbols("StandardCalculatorOperation");
            _symbolDictionary = calc.GetDictionary();
            
            this._result = new TextBox();
            this._equation = new TextBox();
            this.SuspendLayout();
            // 
            // _numberSet
            // 
            
            _numberSet = new TableLayoutPanel();
            _numberSet.ColumnCount = 4;
            _numberSet.RowCount = _symbolDictionary.Count / _numberSet.ColumnCount;
            _numberSet.Name = "_numberSet";
            _numberSet.Size = new Size(370, 390);
            _numberSet.Location = new Point(10, 183);
            _numberSet.Name = "numberSet";
            _numberSet.Anchor = AnchorStyles.Top |AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            // 
            // _result
            // 
            _result.Name = "_result";
            _result.TabIndex = 0;
            _result.Location = new Point(10, 70);
            _result.TextAlign = (HorizontalAlignment)System.Windows.HorizontalAlignment.Right;
            _result.MinimumSize = new Size(370, 90);
            this._result.Size = new Size(222, 217);
            _result.Multiline = true;
            _result.Height = 25;
            _result.Font = new Font("Times New Roman", 42.0f);
            _result.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            // 
            // _equation
            // 
            _equation.Name = "_equation";
            _equation.TabIndex = 0;
            _equation.Location = new Point(10, 10);
            _equation.TextAlign = (HorizontalAlignment)System.Windows.HorizontalAlignment.Right;
            _equation.MinimumSize = new Size(370, 40);
            this._equation.Size = new Size(222, 217);
            _equation.Multiline = true;
            _equation.Height = 25;
            _equation.Font = new Font("Times New Roman", 22.0f);
            _equation.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;

            // 
            // Calculator
            // 
            AutoScaleDimensions = new SizeF(6F, 13F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(394, 576);
            Controls.Add(_result);
            Controls.Add(_equation);
            Controls.Add(this._numberSet);
            FormBorderStyle = FormBorderStyle.Fixed3D;
            Name = "Calculator";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Calculator";
            Load += new EventHandler(CalculatorLoad);
            ResumeLayout(true);
            PerformLayout();

            //
            //Menu
            //
            _mainMenu = new MainMenu();
            MenuItem mainMenuItems = _mainMenu.MenuItems.Add("&☰");
            mainMenuItems.MenuItems.Add(new MenuItem("&Standard", new EventHandler(StandardCalcualtorChoosen)));
            mainMenuItems.MenuItems.Add(new MenuItem("&Scientific", new EventHandler(ScientficCalcualtorChoosen)));
            mainMenuItems.MenuItems.Add(new MenuItem("&Exit", new EventHandler(FileExit_clicked), Shortcut.CtrlX));
            this.Menu = (MainMenu)_mainMenu;
            //_mainMenu.GetForm().BackColor = Color.Indigo;
            
        }

        private void StandardCalcualtorChoosen(object sender, EventArgs e)
        {
            while (_numberSet.Controls.Count > 0)
            {
                _numberSet.Controls[0].Dispose();
            }

            OperationSymbols calc = new OperationSymbols("StandardCalculatorOperation");
            _symbolDictionary = calc.GetDictionary();
            _numberSet.ColumnCount = 4;
            _numberSet.RowCount = _symbolDictionary.Count / _numberSet.ColumnCount;
            CalculatorLoad(sender, e);
        }

        private void ScientficCalcualtorChoosen(object sender, EventArgs e)
        {
            while (_numberSet.Controls.Count > 0)
            {
                _numberSet.Controls[0].Dispose();
            }
            OperationSymbols calc = new OperationSymbols("ScientificCalculatorOperation");
            _symbolDictionary = calc.GetDictionary();
            _numberSet.ColumnCount = 5;
            _numberSet.RowCount = _symbolDictionary.Count / _numberSet.ColumnCount;
            CalculatorLoad(sender, e);
        }

        private void FileExit_clicked(object sender, EventArgs e)
        {
            this.Close();
        }

        private void CalculatorLoad(object sender, EventArgs e)
        {
                  

            int _counter = 0;
            for (int i = 0; i < _numberSet.RowCount; i++)
            {
                for (int j = 0; j < _numberSet.ColumnCount; j++)
                {
                    Button _button = new Button();
                    _numberSet.Controls.Add(_button, j, i);
                    _button.Dock = DockStyle.Fill;
                    _button.Location = new Point(1, 1);
                    _button.Margin = new Padding(1);
                    _button.Name = "button " + _counter.ToString();
                    _button.Size = new Size(380/_numberSet.ColumnCount, 58);
                    _button.Text = _symbolDictionary.Values.ElementAt(_counter).Display;
                    _button.Click += new EventHandler(btnClick);
                    _counter += 1;
                }
            }
            
        }

        private void btnClick(object sender, EventArgs e)
        {
            Button _btn = (Button)sender;

            //Removes alphabets from _button name, leaving only the number i.e. its index at operation dictionary
            int _buttonIndex = int.Parse(Regex.Replace(_btn.Name, "[A-Za-z ]", ""));

            // Displays the symbol in the textbox
            string _displaySymbol = _symbolDictionary.Values.ElementAt(_buttonIndex).Display;

            // Actual symbol in English
            string _expressionSymbol = _symbolDictionary.Values.ElementAt(_buttonIndex).Symbol;

            if (_displaySymbol == _symbolDictionary["ClearAll"].Display)
            {
                _result.Text = string.Empty;
                _expression = string.Empty;
                _equation.Text = string.Empty;
                
            }

            //Clears entry
            else if (_displaySymbol == _symbolDictionary["ClearEntry"].Display)
            {
                _result.Text = string.Empty;
            }

            // Erase
            else if (_displaySymbol == _symbolDictionary["Erase"].Display)
            {
                if (_result.Text.Length > 0)
                {
                    _result.Text = _result.Text.Substring(0, _result.TextLength - _displaySymbol.Length + 1);
                    _expression = _expression.Substring(0, _expression.Length - _displaySymbol.Length + 1);
                    _equation.Text = _result.Text;
                }
            }

            // Decimal
            else if (!_result.Text.Contains(_symbolDictionary["Decimal"].Display) && _displaySymbol == _symbolDictionary["Decimal"].Display)
            {
                if (_result.Text == string.Empty)
                {
                    _result.Text += _symbolDictionary["Zero"].Display;
                    _expression += _symbolDictionary["Zero"].Symbol;
                }
                _result.Text += _displaySymbol;
                _expression += _expressionSymbol;
                _equation.Text = _result.Text;
            }

            //Evaluate
            else if (_displaySymbol == _symbolDictionary["Equal"].Display)
            {
                if (_result.Text != string.Empty)
                {
                    try
                    {
                        ExpresssionEvaluator evaluator = new ExpresssionEvaluator();
                        _result.Text = evaluator.Evaluate(_expression).ToString();
                        _expression = evaluator.Evaluate(_expression).ToString();
                        _equation.Text = "("+_equation.Text+")";
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message);
                    }
                }
            }

            //Operand or operator
            else
            {
                if (_displaySymbol != _symbolDictionary["Decimal"].Display)
                {
                    _result.Text += _expressionSymbol;
                    _expression += _expressionSymbol;
                    _equation.Text += _expressionSymbol;
                }
            }
        }
    }
}
