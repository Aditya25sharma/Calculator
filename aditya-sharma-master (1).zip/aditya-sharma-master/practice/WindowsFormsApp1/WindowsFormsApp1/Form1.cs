﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;
using System.Linq;
using System.Text.RegularExpressions;
using MathLibrary;

namespace WindowsFormsApp1
{
    public partial class Calculator : Form
    {
        // Contains opertors and their symbol
        private Dictionary<string, CalculatorOperations> _symbolDictionary;

        // Equation expression
        private string _expression;

        public Calculator()
        {
            InitializeComponent();
        }

        private void CalculatorLoad(object sender, EventArgs e)
        {
            CalculatorLowerBody calc = new CalculatorLowerBody();
            _symbolDictionary = calc.GetDictionary();

            //Operator and Operaors
            _numberSet.ColumnCount = 4;
            _numberSet.RowCount = _symbolDictionary.Count / _numberSet.ColumnCount;
            _numberSet.Location = new Point(10, 183);
            _numberSet.Name = "numberSet";
            _numberSet.Size = new Size(370, 390);

            int _counter = 0;
            for (int i = 0; i < _numberSet.RowCount; i++)
            {
                for (int j = 0; j < _numberSet.ColumnCount; j++)
                {
                    Button _button = new Button();
                    _numberSet.Controls.Add(_button, j, i);
                    _button.Dock = DockStyle.Fill;
                    _button.Location = new Point(1, 1);
                    _button.Margin = new Padding(1);
                    _button.Name = "button " + _counter.ToString();
                    _button.Size = new Size(95, 58);
                    _button.Text = _symbolDictionary.Values.ElementAt(_counter).Display;
                    _button.Click += new EventHandler(btnClick);
                    _counter += 1;
                }
            }
            _result.Dock = DockStyle.Fill;
            _result.Font = new Font("Arial", 24, FontStyle.Bold);
            _result.TextAlign = (System.Windows.Forms.HorizontalAlignment)System.Windows.HorizontalAlignment.Right;
            _result.Margin = new Padding(10);
        }

        private void btnClick(object sender, EventArgs e)
        {
            Button _btn = (Button)sender;

            //Removes alphabets from _button name, leaving only the number i.e. its index at operation dictionary
            int _buttonIndex = int.Parse(Regex.Replace(_btn.Name, "[A-Za-z ]", ""));

            // Displays the symbol in the textbox
            string _displaySymbol = _symbolDictionary.Values.ElementAt(_buttonIndex).Display;

            // Actual symbol in English
            string _expressionSymbol= _symbolDictionary.Values.ElementAt(_buttonIndex).Symbol;

            if(_displaySymbol ==_symbolDictionary["ClearAll"].Display)
            {
                _result.Text = string.Empty;
                _expression=string.Empty;
            }

            //Clears entry
            else if (_displaySymbol == _symbolDictionary["ClearEntry"].Display)
            {
                _result.Text = string.Empty;
            }

            // Erase
            else if(_displaySymbol==_symbolDictionary["Erase"].Display)
            {
                if(_result.Text.Length>0)
                {
                    _result.Text = _result.Text.Substring(0, _result.TextLength - _displaySymbol.Length + 1);
                    _expression=_expression.Substring(0, _expression.Length - _displaySymbol.Length+1);
                }
            }

            // Decimal
            else if (!_result.Text.Contains(_symbolDictionary["Decimal"].Display) && _displaySymbol==_symbolDictionary["Decimal"].Display)
            {
                if(_result.Text == string.Empty)
                {
                    _result.Text += _symbolDictionary["Zero"].Display;
                    _expression += _symbolDictionary["Zero"].Symbol;
                }
                _result.Text += _displaySymbol;
                _expression += _expressionSymbol;
            }

            //Evaluate
            else if (_displaySymbol == _symbolDictionary["Equal"].Display)
            {
                if(_result.Text != string.Empty)
                {
                    try
                    {
                        ExpresssionEvaluator evaluator = new ExpresssionEvaluator();
                        _result.Text = evaluator.Evaluate(_expression).ToString();
                        _expression = evaluator.Evaluate(_expression).ToString();
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message);
                    }
                }
            }

            //Operand or operator
            else
            {
                if(_displaySymbol != _symbolDictionary["Decimal"].Display)
                {
                    _result.Text += _expressionSymbol;
                    _expression += _expressionSymbol;
                }
            }
        }
    }
}
/*
 using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using CalculatorLibrary;

namespace CalculatorUI
{
    public partial class Calculator : Form
    {
        private ExpressionEvaluator _evaluator = new ExpressionEvaluator();
        private SplitContainer _splitContainer;
        private TextBox _display;
        private TableLayoutPanel _tableLayout;
        private List<Button> _buttonList;
        private Button _buttonClear;
        private Button _buttonDelete;
        private MenuStrip _mainMenuStrip;
        private ToolStripMenuItem _editToolStripMenuItem;
        private ToolStripMenuItem _exitToolStripMenuItem;
        private ToolStripMenuItem _helpToolStripMenuItem;
        private Font _fontStyle = new Font("Microsoft Sans Serif", 17F);
        private Stack<string> _lastButtonPressed = new Stack<string>();

        public Calculator()
        {
            InitializeComponent();
            
            /// Split container Layout
            _splitContainer = new SplitContainer()
            {
                Name = "SplitContainer",
                Dock = DockStyle.Fill,
                Orientation = Orientation.Horizontal,
                Location = new Point(0, 0),
                Size = new Size(150,250),
                SplitterDistance = 30,
                IsSplitterFixed = true
            };
            Controls.Add(_splitContainer);

            /// TextBox or Display
            _display = new TextBox()
            {
                Name = "Display",
                Font = new Font("Microsoft Sans Serif", 18F),
                Dock = DockStyle.Bottom,
                TextAlign = HorizontalAlignment.Right,
                ReadOnly = true,
            };
            _splitContainer.Panel1.Controls.Add(_display);

            /// Adding numeric Buttons to ButtonList
            
            _buttonList = new List<Button>();

            _buttonList.Add(new Button()
            {
                Text = ".",
                Dock = DockStyle.Fill,
                Font = _fontStyle,
            });
            _buttonList.Add(new Button()
            {
                Text = "0",
                Dock = DockStyle.Fill,
                Font = _fontStyle,
            });
            _buttonList.Add(new Button()
            {
                Text = "=",
                Dock = DockStyle.Fill,
                Font = _fontStyle,
            });

            for(int i = 1; i <= 9; i++)
            {
                _buttonList.Add(new Button() { 
                    Text = i.ToString(),
                    Dock = DockStyle.Fill,
                    Font = _fontStyle,
                });
            }          

            /// Adding Buttons to ArithmeticPad

            _buttonList.Add(new Button()
            {
                Text = "(",
                Dock = DockStyle.Fill,
                Font = _fontStyle,
            });
            _buttonList.Add(new Button()
            {
                Text = ")",
                Dock = DockStyle.Fill,
                Font = _fontStyle,
            });
            foreach (string op in _evaluator.operatorSymbols)
            {
                _buttonList.Add(new Button()
                {
                    Text = op,
                    Dock = DockStyle.Fill,
                    Font = _fontStyle,
                });
            }

            /// Adding Event Handler to _buttonList
            for (int i = 0; i < _buttonList.Count; i++)
            {
                _buttonList[i].Click += new EventHandler(btn_Click);
            }


            ///Table Layout
            _tableLayout = new TableLayoutPanel()
            {
                Name = "TableLayout",
                RowCount = 5,
                ColumnCount = (int)Math.Ceiling(Convert.ToDouble(_buttonList.Count / 4)),
                Dock = DockStyle.Fill,
            };
            for (int i = 0; i < _tableLayout.ColumnCount; i++)
            {
                _tableLayout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100 / _tableLayout.ColumnCount));
            }
            for (int i = 0; i < _tableLayout.RowCount; i++)
            {
                _tableLayout.RowStyles.Add(new RowStyle(SizeType.Percent, 100 / _tableLayout.RowCount));
            }
            _splitContainer.Panel2.Controls.Add(_tableLayout);

            /// Adding Clear, Delete buttons to top right of calculator
            _buttonClear = new Button()
            {
                Text = "clear",
                Dock = DockStyle.Fill,
                Font = _fontStyle
            };
            _buttonClear.Click+= new EventHandler(btn_Click);


            _buttonDelete = new Button()
            {
                Text = "delete",
                Dock = DockStyle.Fill,
                Font = _fontStyle
            };
            _buttonDelete.Click += new EventHandler(btn_Click);


            _tableLayout.Controls.Add(_buttonDelete, _tableLayout.ColumnCount - 1, 0); 
            _tableLayout.Controls.Add(_buttonClear, _tableLayout.ColumnCount - 2, 0);

            /// Adding Buttons to table layout panel

            int count = 0;
            /// Adding Numerical keyPad
            for (int i = _tableLayout.RowCount - 1; i > 0; i--)
            {
                for (int j = _tableLayout.ColumnCount-3; j < _tableLayout.ColumnCount ; j++)
                {
                    if (count < _buttonList.Count)
                    {
                        _tableLayout.Controls.Add(_buttonList[count++], j, i);
                    }
                }
            }

            /// Adding Arithmetic Pad

            for (int i=_tableLayout.RowCount-1; i>0; i--)
            {
                for(int j = 0; j < _tableLayout.ColumnCount-3; j++)
                {
                    if (count < _buttonList.Count)
                    {
                        _tableLayout.Controls.Add(_buttonList[count++],j,i);
                    }
                }
            }

            /// MenuStrip
            _mainMenuStrip = new MenuStrip()
            {
                Name = "MainMenu",
                Dock = DockStyle.Top,
            };
            _editToolStripMenuItem = new ToolStripMenuItem()
            {
                Name = "EditMenu",
                Text = "Edit",
            };
            _exitToolStripMenuItem = new ToolStripMenuItem()
            {
                Name = "ExitMenu",
                Text = "Exit"
            };
            _helpToolStripMenuItem = new ToolStripMenuItem()
            {
                Name = "HelpMenu",
                Text = "Help"
            };
            _editToolStripMenuItem.DropDownItems.Add("Copy");
            _editToolStripMenuItem.DropDownItems.Add("Paste");
            _mainMenuStrip.Items.Add(_editToolStripMenuItem);
            _mainMenuStrip.Items.Add(_exitToolStripMenuItem);
            _mainMenuStrip.Items.Add(_helpToolStripMenuItem);
            Controls.Add(_mainMenuStrip);

        }

        private void CalculatorLoad(object sender, EventArgs e)
        {

        }

        private void btn_Click(object sender, EventArgs e)
        {
            Button _btn = (Button)sender;
            if (_btn.Text == "=")
            {
                try
                {
                    _display.Text = Convert.ToString(_evaluator.Evaluate(_display.Text));
                    _lastButtonPressed.Clear();
                    _lastButtonPressed.Push(_display.Text);
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
            else if(_btn.Text == ".")
            {
                
            }
            else if(_btn.Text == "delete")
            {
                string lastBtn = "";
                if (_lastButtonPressed.Count() > 0)
                {
                    lastBtn = _lastButtonPressed.Pop();
                    _display.Text = _display.Text.Remove(_display.Text.Length - lastBtn.Length);
                }
           
            }
            else if (_btn.Text == "clear")
            {
                _display.Text = "";
                _lastButtonPressed.Clear();
            }
            else
            {
                if (_btn.Text[0] >= 'a' && _btn.Text[0] <= 'z')
                {
                    _lastButtonPressed.Push(_btn.Text + "(");
                    _display.Text += (_btn.Text + "(");
                }
                else
                {
                    _lastButtonPressed.Push(_btn.Text);
                    _display.Text += (_btn.Text);
                }
            }
        }
    }

}

 
 */