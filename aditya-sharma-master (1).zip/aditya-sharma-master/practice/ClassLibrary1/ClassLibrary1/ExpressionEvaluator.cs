﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary1
{
    class ExpresssionEvaluator : IOperation
    {
        public void RegisterCustomOperation(string ioperation, string symbol, string precedence)
        {
        }
        public double Evaluate(double[] values)
        {
            throw new NotImplementedException();
        }
        public int OperandCount { get; set; }
    }
}
