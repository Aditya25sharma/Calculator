﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary1
{
    abstract class UnaryOperation : IOperation
    {
        public abstract double Evaluate(double[] values);
        public int OperandCount
        {
            get { return OperandCount; }
            set { OperandCount = 1; }
        }

        public UnaryOperation()
        { }
    }
}
