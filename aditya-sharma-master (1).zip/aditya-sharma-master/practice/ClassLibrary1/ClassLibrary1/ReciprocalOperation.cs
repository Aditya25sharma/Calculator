﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary1
{
    class ReciprocalOperation : UnaryOperation
    {
        public override double Evaluate(double[] values)
        {
            throw new NotImplementedException();
        }
    }
}
