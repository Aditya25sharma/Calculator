﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary1
{
    internal class SumOperation : BinaryOperation
    {
        protected override double EvaluateInternal(double[] values)
        {
            return values[0]+values[1];
        }
    }
}